#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "SimpleDb.h"

//Variables:
extern  Student_t   SDB_Stud[10];   //creating an array of 10 student databases.
//extern  Student_t   *ptr[10];
extern  uint8_t     counter;        //counter variable to loop and track array elements.
//extern  uint8_t     Full_Empty_Flag;
//Interfaces should be provided in this module:
/*----Function--Implemetations---*/

//*ptr[] = &SDB_Stud[];
//Func#1: to check if the database is full:
bool SDB_IsFull(void)
{
    for(int i = 0; i < 10; i++)
    {
        if(SDB_Stud[i].Stud_ID == 0)
        {
            printf("Database is empty. \n");
            break;
        }
        else
            {
                 printf("Database is not empty. \n");
                 break;
            }
    }
}

//Func#2: to get the number of entries in the database:
uint8_t SDB_GetUsedSize(void)
{
    uint8_t size = 0;
    for(int i = 0; i < 10; i++)
    {
        if(SDB_Stud[i].Stud_ID != 0)
        {
            size = size + 1;
            //printf("Database is empty. \n");
            //break;
        }
    }
    printf("Size of the Database is %d. \n", size);
    counter = size;
}

//Func#3: Add new entry to the database:
bool SDB_AddEntry(uint8_t id, uint8_t year, uint8_t* subjects, uint8_t* grades)
{
    SDB_Stud[counter].Stud_ID = id;

    SDB_Stud[counter].Stud_Yr = year;
    //uint8_t* ptr_sub = SDB_Stud[counter].Course_ID;
    //ptr_sub = &subjects;
    //uint8_t* ptr_grd = &grades;
    for(int sub_cnt = 0; sub_cnt < 3; sub_cnt++)
    {
        SDB_Stud[counter].Course_ID[sub_cnt] = &subjects;
        //SDB_Stud[counter].(*ptr_sub[sub_cnt]) = subjects;
    }

    for(int grd_cnt = 0; grd_cnt < 3; grd_cnt++)
    {
        SDB_Stud[counter].Course_Grd[grd_cnt] = &grades;
    }
}

//Func#4: Delete the entry with the given ID:
void SDB_DeleteEntry(uint8_t id)
{
    for (int s = 0; s < 10; s++)
    {
        if(SDB_Stud[s].Stud_ID = id)
        {
            SDB_Stud[s].Stud_ID = 0;
            SDB_Stud[s].Stud_Yr = 0;
            for (int q = 0; q < 2; q++)
            {
                SDB_Stud[s].Course_ID[q] = 0;
                SDB_Stud[s].Course_Grd[q] = 0;
            }
            printf("The data of the student whose ID is %d has been deleted. \n", id);
            break;
        }
        else
        {
            printf("There is no matching ID in the database ! \n");
        }


        //printf("ID of student %d is %d \n" , s, SDB_Stud[s].Stud_ID);
    }
}

//Func#5: read an entry matching the provided ID:
bool SDB_ReadEntry(uint8_t id, uint8_t year, uint8_t* subjects, uint8_t* grades)
{
    for(int i = 0; i < 10; i++)
    {
        if(SDB_Stud[i].Stud_ID == id)
        {
            //Student_t  *ptr_sub;
            //ptr_sub = &(SDB_Stud[i]);
            //printf("ID is %d \n", ptr_sub);

            printf("The year of the matching student ID is : %d \n", SDB_Stud[i].Stud_Yr);
            for(int j = 0; j < 3; j++)
            {
                printf("The ID of the subject no. %d is %d. \n", (j+1), (SDB_Stud[i].Course_ID[j]));
                //printf("The ID of the subject no. %d is %d. \n", (j+1), ((*ptr_sub).Course_ID[j]));

                printf("The grade of the subject no. %d is %d. \n", (j+1), &(SDB_Stud[i].Course_Grd[j]));

            }
            break;
        }
        else
        {
            printf("There is no matching ID in the database ! \n");
        }
    }
}

//Func#6: Get the list of IDs of the students:
void SDB_GetIdList(uint8_t* count, uint8_t* list)
{
    count = SDB_GetUsedSize();
    printf("Number of students in the list is %d . \n", count);
    for(int i = 0; i < count; i++)
    {
        if(SDB_Stud[i].Stud_ID != 0)
        {
            list[i] = SDB_Stud[i].Stud_ID;
            printf("Available student ID is ( %d ) . \n", list[i]);
        }
    }
}

//Func#7: Checks if the provided student ID exists:
bool SDB_IsIdExist(uint8_t id)
{
    for(int i = 0; i < 10; i++)
    {
        if(SDB_Stud[i].Stud_ID = id)
        {
            printf("ID %d is available in the database. \n", id);
        }
        else
        {
            printf("ID %d is not available in the database. \n", id);
        }
    }
}

    printf("Fuck you");
}
