#ifndef SIMPLEDB_H_INCLUDED
#define SIMPLEDB_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>


//NOTE:The maximum size of the database is 10 entries.

typedef struct Student // creating a data structure of type "Student"
{
    uint8_t     Stud_ID;        //student ID
    uint8_t     Stud_Yr;        //student year
    uint8_t     Course_ID[3];    //an array containing the IDs of different courses for each studetn
    uint8_t     Course_Grd[3];   //an array containing the grades of each course in the above list (allowed range from 0 to 100)
    //There is an assumption in the assignment givens saying that: caller will always provide the 3 subjects with their grades.
}Student_t;

//Interfaces should be provided in this module:
/*----Function--Prototypes---*/

//Func#1: to check if the database is full:
bool SDB_IsFull(void);

//Func#2: to get the number of entries in the database:
uint8_t SDB_GetUsedSize(void);

//Func#3: Add new entry to the database:
bool SDB_AddEntry(uint8_t id, uint8_t year, uint8_t* subjects, uint8_t* grades);


//Func#4: Delete the entry with the given ID:
void SDB_DeleteEntry(uint8_t id);

//Func#5: read an entry matching the provided ID:
bool SDB_ReadEntry(uint8_t id, uint8_t year, uint8_t* subjects, uint8_t* grades);

//Func#6: Get the list of IDs of the students:
void SDB_GetIdList(uint8_t* count, uint8_t* list);

//Func#7: Checks if the provided student ID exists:
bool SDB_IsIdExist(uint8_t id);

#endif // SIMPLEDB_H_INCLUDED
