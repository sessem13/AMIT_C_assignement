#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "SimpleDb.h"

Student_t   SDB_Stud[10];
uint8_t     counter;
//uint8_t     Full_Empty_Flag;


int main()
{
    /*
    //Database initialziation with 0 or clear information:
    printf("Initialzing all the database elements to zero information: \n");
    for (int s = 0; s < 10; s++)
    {
        SDB_Stud[s].Stud_ID = 0;
        SDB_Stud[s].Stud_Yr = 0;
        for (int q = 0; q < 2; q++)
        {
            SDB_Stud[s].Course_ID[q] = 0;
            SDB_Stud[s].Course_Grd[q] = 0;
        }
        //printf("ID of student %d is %d \n" , s, SDB_Stud[s].Stud_ID);
    }
    */



    uint8_t     Options_Input;
Menu:
    printf("===========MENU=OF=OPTIONS============\n");
    printf("\n");
    printf("# To add new entry to the database enter                        '1' : \n");
    printf("# To check the size/length of the database enter                '2' : \n");
    printf("# To check if the database is full or empty enter               '3' : \n");
    printf("# To delete an entry of the database enter                      '4' : \n");
    printf("# To read the data of an entry enter                            '5' : \n");
    printf("# To view a list of all IDs available enter                     '6' : \n");
    printf("# To check if an ID you have is available in the database enter '7' : \n");
    printf("# To exit this database program enter                           '0' : \n");
    printf("\n");
    printf("=============END=OF=MENU==============\n");

    scanf(" %c", &Options_Input);

    switch(Options_Input)
    {
    case('3'):
        SDB_IsFull();
        goto Menu;

    case('2'):
        SDB_GetUsedSize();
        goto Menu;

    case('1'):
        {
            uint8_t id_rd, yr_rd;
            uint8_t sub_rd[3];
            uint8_t grd_rd[3];

            printf("Please insert student's ID (non zero value): \n");
            scanf(" %d", &id_rd);

            printf("Please insert student's year (non zero value): \n");
            scanf(" %d", &yr_rd);

            for(int sub_cnt = 0; sub_cnt < 3; sub_cnt++)
                {
                    uint8_t subject_read;
                    printf("Please insert subject # %d ID for this student (non zero value): \n", (sub_cnt+1));
                    scanf(" %d", &subject_read);
                    sub_rd[sub_cnt] = subject_read;
                }

            for(int grd_cnt = 0; grd_cnt < 3; grd_cnt++)
                {
                    uint8_t subject_grade;
                    printf("Please insert subjects # %d grades for this student (range from 0 to 100 only): \n", (grd_cnt+1));
                    scanf(" %d", &subject_grade);
                    grd_rd[grd_cnt] = subject_grade;
                }

            SDB_AddEntry(id_rd, yr_rd, sub_rd, grd_rd);
        }
        counter++;
        goto Menu;

    case('4'):
        {
            uint8_t x_id;
            printf("Please enter the student ID: \n");
            scanf("%d", &x_id);
            SDB_DeleteEntry(x_id);
            goto Menu;
        }

    case('5'):
        {
            uint8_t y_id;
            printf("Please enter the student ID: \n");
            scanf("%d", &y_id);
            SDB_ReadEntry(y_id, 0, 0 , 0);
            goto Menu;
        }
    case('6'):
        {
            uint8_t list[counter];
            SDB_GetIdList(counter, list);
            goto Menu;
        }
    case('7'):
        {
            uint8_t ID_Check;
            printf("Please insert the ID you want to check for: \n");
            scanf("%d", &ID_Check);
            SDB_IsIdExist(ID_Check);
            goto Menu;
        }

    case('0'):
        break;
    }



    return 0;
}
